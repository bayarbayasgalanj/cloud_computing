<!DOCTYPE html>
<html>
  <head>
    <title>AWS Tech Fundamentals Bootcamp</title>
    <link href="style.css" media="all" rel="stylesheet" type="text/css" />
  </head>

  <body>
    <div id="wrapper">

      <?php include('menu.php'); ?>

      <?php include('put-cpu-load.php'); ?>

      <hr />

      <?php include('get-cpu-load.php'); ?>

    </div>
  </body>
</html>
